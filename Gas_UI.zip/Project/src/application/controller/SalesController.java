package application.controller;

public class SalesController {

}
