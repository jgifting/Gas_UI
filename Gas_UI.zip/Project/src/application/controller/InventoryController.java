package application.controller;

public class InventoryController {

}
