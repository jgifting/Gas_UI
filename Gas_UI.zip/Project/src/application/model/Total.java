package application.model;

public class Total {

}
