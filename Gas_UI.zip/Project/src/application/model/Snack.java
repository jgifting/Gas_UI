package application.model;

public class Snack {

}
